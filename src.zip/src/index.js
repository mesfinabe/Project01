import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
 <center><h2> Simple <br/>Calculator Application  <br>
 </br> by using React components </h2></center> 
    <App />
    <center>&copy;<i class="fa fa-copyright" aria-hidden="true">2024. Developed by: Mesfin A</i></center>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals

